#Main Code
from ObjectAvoidance import Avoidance
from MotorMovement import Move


def Normalizing_Path():
    print("-Normalizing Path-")
    motor.runMotor(motor.movement, motor.spd)

    #after the left turn, rover needs to turn back to the right
    if motor.movement is "left":
        motor.runMotor("right", motor.spd)
        motor.movement = "forward" #rover is now on path

    #after the right turn, rover needs to turn back to the left
    elif motor.movement is "right":
        motor.runMotor("left", motor.spd)
        motor.movement = "forward" #rover is now on path

if __name__ == '__main__':
    rover = Avoidance(direction = "forward", )
    motor = Move(movement = rover.direction, spd = 35)

    #start initial moving
    motor.runMotor(motor.movement, motor.spd)

    while(True):
        #detecting if object is in front of rover
        clear = Avoidance.sensor_value(rover)
        if(clear is False):
            motor.motorStop()
            rover.direction = Avoidance.Check_Right_Left(rover)
            motor.movement = rover.direction
            Normalizing_Path()

        else:
            Normalizing_Path()

        rover.direction = motor.movement









