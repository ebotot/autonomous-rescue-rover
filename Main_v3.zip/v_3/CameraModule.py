from _future_ import division
import cv2
import numpy as np
from math import cos, sin

green = (0, 255, 0)

def show(image):
    #figure size in inches
    plt.figure(figsize=(10, 10))
    #show image with nearest neighbor interpolation
    plt.imshow(image, interpolation='nearest')

def overlay_mask(mask, image):
    #make the mask rgb values
    rgb_mask = cv2.cvtColor(mask, cv2.COLOR_GRAY2RGB)       #conversts grayscale to rgb

    #calculate the weights of the sum of two arrays
    #input should be how much weight to each
    img = cv2.addWeighted(rgb_mask, 0.5, image, 0.5, 0)
    return img

def find_biggest_contour(image):
    #copy image for contour comparison
    image = image.copy()

    contours, hierarchy = cv2.findContours(image, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)

    #isolate the largest contouor of image
    contour_sizes = [(cv2.contourArea(contour), contour) for contour in contours]
    biggest_contour = max(contour_sizes, key=lambda x: x[0])[1]

    mask = np.zeros(image.shape, np.uint8)
    cv2.drawContours(mask, [biggest_contour], -1, 255, -1)
    return biggest_contour, mask

def circle_contour(image, contour):
    #introduces a bounding ellipse
    image_with_ellipse = image.copy()
    ellipse = cv2.fitEllipse(contour)
    cv2.ellipse(image_with_ellipse, ellipse, green, 2, cv2.LINE_AA)
    return image_with_ellipse

def find_object(image):
    #rgb is stored in a structure or unsidgned integer with
    #blue occupying the least significant area, green occupying the
    #second least significant, and then red
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    #make consistency in size
    #obtain largest dimension
    max_dimension = max(image.shape)

    #max window size is 700 by 660 pixels
    scale = 700/max_dimension
    image = cv2.resize(image, None, fx=scale, fy=scale)

    #eliminate noise from image
    #blur image using Gaussian filter
    image_blur = cv2.GaussianBlur(image, (7, 7), 0)

    #use hsv to separate luma, or image intensity from chroma
    image_blur_hsv = cv2.cvtColor(image_blur, cv2.COLOR_RGB2HSV)

    #filter by color

    #hue 0-10
    min_red = np.array([0, 100, 80])
    max_red = np.array([10, 256,, 256])

    #first layer
    mask1 = cv2.inRange(image_blur_hsv, min_red, max_red)

    #hue 170-180
    min_red2 = np.array([170, 100, 80])
    max_red2 = np.array([180, 256, 256])
    mask2 = cv2.inRange(image_blur_hsv, min_red2, max_red2)

    #to look for both range, combine layers
    mask = mask1 + mask2

    #clean up and identify object
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
    mask_closed = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

    #remove noise
    mask_clean = cv2.morphologyEx(mask_closed, cv2.MORPH_OPEN, kernel)

    big_object_contour, mask_objects = find_biggest_contour(mask_clean)

    #overlay cleaned mask on image
    #overlay mask on image, object now segmented
    overlay = overlay_mask(mask_clean, image)

    #circle object filter
    circled = circle_contour(overlay, big_object_contour)
    show(circled)

    #convert back to original color scheme
    bgr = cv2.cvtColor(circled, cv2.COLOR_RGB2BGR)

    return bgr

    #read image
    #image = cv2.imread('insert jpg')
    #result = find_object(image)

    #write new image
    #cv2.imwrite('insert jpg', result)


#print(cv2.__version__)
#print(np.__version__)
#print(matplotlib.__version__)